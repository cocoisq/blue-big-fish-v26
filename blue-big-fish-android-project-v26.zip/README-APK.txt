藍色大肥魚 V26 Android APK 封裝專案

這是完整 Android Gradle 專案，遊戲網頁與兩首 MP3 已放入：
TapMaidWidget_Release/app/src/main/assets/

使用原本 cocoisq/blue-big-fish GitHub Actions 的最簡單方式：
1. 將這個 ZIP 上傳到 GitHub repository 根目錄，並把檔名改成原本的 blue-big-fish-android-project-v26.zip（覆蓋舊檔）。
2. 原本 .github/workflows/build-apk.yml 會因為這個檔案更新而自動開始建置。
3. 打開 GitHub → Actions → 最新的 Build Blue Big Fish APK 執行紀錄。
4. 在 Artifacts 下載 blue-big-fish-apk.zip，解壓後取得 app-debug.apk。

也可使用本 ZIP 內附的 build-apk-v26.yml，放到 .github/workflows/build-apk-v26.yml，並將 ZIP 存成 blue-big-fish-android-project-v26.zip 後手動執行該 workflow。

專案使用 Android Gradle Plugin 8.7.3、Gradle 8.9、JDK 17；Java/Kotlin bytecode target 均設為 1.8，與舊版 workflow 的 Kotlin target 設定相容。
本環境沒有 Android SDK，因此這裡提供的是完整可建置專案 ZIP，不是已編譯 APK。

V26 修正：播放期間加入點擊間隔檢查，過快/過慢點擊會立即停止音樂；新增極為困難（22 ms 容差）。Android app versionCode/versionName 已更新為 26/26.0。
